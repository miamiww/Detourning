from setuptools import setup

setup(name="shuttertalk10",
    version="0.1",
    description="something",
    url="alden.life",
    author="Alden",
    author_email="rivendalejones@gmail.com",
    license="GPL",
    packages=["shuttertalk"],
    scripts=["bin/shuttertalk"],
    install_requires=["bs4", "requests"])
