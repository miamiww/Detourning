Slidepull
---------
To use::
        >>> import slidepull
        >>> slidepull.new_slide()

